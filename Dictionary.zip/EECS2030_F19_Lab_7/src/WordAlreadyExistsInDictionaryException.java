
public class WordAlreadyExistsInDictionaryException extends Exception {

	public WordAlreadyExistsInDictionaryException(String s) {
		super(s);
	}

}
