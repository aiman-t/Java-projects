
public class WordNotInDictionaryException extends Exception {

	public WordNotInDictionaryException(String s) {
		super(s);
	}
}
