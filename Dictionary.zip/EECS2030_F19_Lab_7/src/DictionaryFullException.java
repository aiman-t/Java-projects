public class DictionaryFullException extends Exception {
	public DictionaryFullException(String s) {
		super(s);
	}
}